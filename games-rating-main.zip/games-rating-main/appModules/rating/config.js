const PATH_TO_PATING_FILE = "./dataset/rating.json";

const WEIGHT = {
    gameplay: 2,
    design: 1,
    idea: 3,
  };

module.exports = {
    PATH_TO_PATING_FILE,
    WEIGHT
}

